/* seeds/seed.js
 * Bulk seed for GamersUnite
 * - Inserts/updates Games by slug
 * - Replaces their Levels (3 per game)
 * Run: node seeds/seed.js
 */

require('dotenv').config()
const mongoose = require('mongoose')
// near the top, after Game/Level imports
let User = require('../models/User')
User = User.default || User


let Game = require('../models/Game')
Game = Game.default || Game

let Level = require('../models/Level')
Level = Level.default || Level




async function connect() {
  const uri = process.env.MONGODB_URI
  if (!uri) {
    console.error('Missing MONGODB_URI in .env')
    process.exit(1)
  }
  await mongoose.connect(uri)
  console.log('Connected to MongoDB')
}

async function getSeederUserId() {
  const u = await User.findOne()
  if (u) return u._id
  console.warn('No users found — seeding levels with a placeholder ObjectId for createdBy.')
  return new mongoose.Types.ObjectId()
}

function pic(seed) {
  // lightweight placeholder cover
  return `https://picsum.photos/seed/${encodeURIComponent(seed)}/800/450`
}

const GAMES = [
  {
    title: 'Elden Ring',
    slug: 'elden-ring',
    description:
      'A vast action RPG with open-world exploration, brutal bosses, and deep build variety.',
    coverUrl: pic('elden-ring'),
    genres: ['Action RPG', 'Soulslike'],
    platforms: ['PC', 'PS5', 'XSX'],
    levels: [
      { number: 1, title: 'Limgrave Start', summary: 'First steps, Church of Elleh, Gatefront guidance.' },
      { number: 2, title: 'Stormveil Approach', summary: 'Margit encounter and castle entry routes.' },
      { number: 3, title: 'Godrick the Grafted', summary: 'Boss patterns, summons, and bleed tips.' },
    ],
  },
  {
    title: 'The Legend of Zelda: Tears of the Kingdom',
    slug: 'zelda-tears-of-the-kingdom',
    description:
      'Sandbox adventure with fusing, building, and emergent puzzle solutions across Hyrule and the skies.',
    coverUrl: pic('totk'),
    genres: ['Adventure', 'Puzzle'],
    platforms: ['Switch'],
    levels: [
      { number: 1, title: 'Great Sky Island', summary: 'Shrines order, early fusions, battery tips.' },
      { number: 2, title: 'Hyrule Surface', summary: 'Towers, map reveals, efficient traversal.' },
      { number: 3, title: 'First Regional Phenomenon', summary: 'Dungeon prep and boss mechanics.' },
    ],
  },
  {
    title: 'God of War Ragnarök',
    slug: 'god-of-war-ragnarok',
    description:
      'Narrative-driven action with runic builds, companion synergy, and layered combat.',
    coverUrl: pic('gow-ragnarok'),
    genres: ['Action', 'Story'],
    platforms: ['PS5', 'PS4', 'PC'],
    levels: [
      { number: 1, title: 'Surviving Fimbulwinter', summary: 'Early skill picks and stun management.' },
      { number: 2, title: 'Svartalfheim', summary: 'Dwarven puzzles and sidequest routing.' },
      { number: 3, title: 'Vanaheim', summary: 'Armor upgrades, status effects, boss tips.' },
    ],
  },
  {
    title: 'Hollow Knight',
    slug: 'hollow-knight',
    description:
      'A metroidvania with tight combat, exploration, and challenging optional content.',
    coverUrl: pic('hollow-knight'),
    genres: ['Metroidvania', 'Action'],
    platforms: ['PC', 'Switch', 'PS4', 'Xbox'],
    levels: [
      { number: 1, title: 'Forgotten Crossroads', summary: 'Early masks, charms, map buying.' },
      { number: 2, title: 'Greenpath', summary: 'Hornet strategies and platforming routes.' },
      { number: 3, title: 'City of Tears', summary: 'Stag stations, nail upgrades, geo farming.' },
    ],
  },
  {
    title: 'Hades',
    slug: 'hades',
    description:
      'Fast roguelike runs, boons synergy, weapon aspects, and boss learning.',
    coverUrl: pic('hades'),
    genres: ['Roguelike', 'Action'],
    platforms: ['PC', 'Switch', 'PS5', 'XSX'],
    levels: [
      { number: 1, title: 'Tartarus', summary: 'Core boons and dash timing.' },
      { number: 2, title: 'Asphodel', summary: 'Environmental hazards and mid-run pivots.' },
      { number: 3, title: 'Elysium', summary: 'Champions fight and deflect builds.' },
    ],
  },
  {
    title: 'Celeste',
    slug: 'celeste',
    description:
      'Precision platformer with assist options and deep movement tech.',
    coverUrl: pic('celeste'),
    genres: ['Platformer'],
    platforms: ['PC', 'Switch', 'PS4', 'Xbox'],
    levels: [
      { number: 1, title: 'Forsaken City', summary: 'Basic dashes and strawberry routes.' },
      { number: 2, title: 'Old Site', summary: 'Dream blocks and timing drills.' },
      { number: 3, title: 'Celestial Resort', summary: 'Mr. Oshiro chase consistency.' },
    ],
  },
  {
    title: 'Dark Souls III',
    slug: 'dark-souls-3',
    description:
      'Punishing combat, intricate level design, and boss mastery.',
    coverUrl: pic('ds3'),
    genres: ['Action RPG', 'Soulslike'],
    platforms: ['PC', 'PS4', 'Xbox'],
    levels: [
      { number: 1, title: 'High Wall of Lothric', summary: 'Shortcut unlocks, Estus routing.' },
      { number: 2, title: 'Undead Settlement', summary: 'NPC saves and early upgrade shards.' },
      { number: 3, title: 'Abyss Watchers', summary: 'Phase management and parry windows.' },
    ],
  },
  {
    title: 'Bloodborne',
    slug: 'bloodborne',
    description:
      'Aggressive combat, rally system, and cosmic horror secrets.',
    coverUrl: pic('bloodborne'),
    genres: ['Action RPG', 'Soulslike'],
    platforms: ['PS4'],
    levels: [
      { number: 1, title: 'Central Yharnam', summary: 'Shortcut tour and molotov usage.' },
      { number: 2, title: 'Cathedral Ward', summary: 'Twin shards and rune access.' },
      { number: 3, title: 'Vicar Amelia', summary: 'Limb focus and fire buffs.' },
    ],
  },
  {
    title: 'Super Metroid',
    slug: 'super-metroid',
    description:
      'Classic metroidvania with sequence breaks and clean routing.',
    coverUrl: pic('super-metroid'),
    genres: ['Metroidvania'],
    platforms: ['SNES', 'Switch'],
    levels: [
      { number: 1, title: 'Brinstar', summary: 'Missiles, morph ball, early E-tanks.' },
      { number: 2, title: 'Norfair', summary: 'Varia suit timing and heat routes.' },
      { number: 3, title: 'Wrecked Ship', summary: 'Phantoon patterns and cleanup.' },
    ],
  },
  {
    title: 'Portal 2',
    slug: 'portal-2',
    description:
      'Physics puzzles with gels, lasers, and witty narrative.',
    coverUrl: pic('portal-2'),
    genres: ['Puzzle'],
    platforms: ['PC', 'PS3', 'Xbox 360', 'Switch'],
    levels: [
      { number: 1, title: 'Intro Chambers', summary: 'Portal fundamentals and timing.' },
      { number: 2, title: 'Gels', summary: 'Repulsion & propulsion combos.' },
      { number: 3, title: 'Laser & Funnels', summary: 'Multi-room solutions.' },
    ],
  },
  {
    title: 'The Witcher 3: Wild Hunt',
    slug: 'the-witcher-3',
    description:
      'Open-world RPG with impactful quests and build crafting.',
    coverUrl: pic('witcher-3'),
    genres: ['RPG', 'Open World'],
    platforms: ['PC', 'PS5', 'XSX', 'Switch'],
    levels: [
      { number: 1, title: 'White Orchard', summary: 'Tutorial gear and oils basics.' },
      { number: 2, title: 'Velen', summary: 'Efficient quest routing and XP.' },
      { number: 3, title: 'Novigrad/Skellige', summary: 'Gear sets and potion synergy.' },
    ],
  },
  {
    title: 'Stardew Valley',
    slug: 'stardew-valley',
    description:
      'Farming, relationships, and min-maxing seasons and profits.',
    coverUrl: pic('stardew'),
    genres: ['Simulation'],
    platforms: ['PC', 'Switch', 'PS4', 'Xbox', 'Mobile'],
    levels: [
      { number: 1, title: 'Spring Year 1', summary: 'Crop choices and tool upgrade timing.' },
      { number: 2, title: 'Mines Early', summary: 'Food, bombs, elevator goals.' },
      { number: 3, title: 'Summer Year 1', summary: 'Sprinklers and profit spikes.' },
    ],
  },
  {
    title: 'Minecraft',
    slug: 'minecraft',
    description:
      'Sandbox survival with crafting, redstone, and infinite creativity.',
    coverUrl: pic('minecraft'),
    genres: ['Sandbox', 'Survival'],
    platforms: ['PC', 'Consoles', 'Mobile'],
    levels: [
      { number: 1, title: 'Day 1 Start', summary: 'Shelter, tools, and food basics.' },
      { number: 2, title: 'Nether Prep', summary: 'Enchantments and blaze rods.' },
      { number: 3, title: 'End Dragon', summary: 'Bed strats and pillar control.' },
    ],
  },
  {
    title: 'DOOM Eternal',
    slug: 'doom-eternal',
    description:
      'High-speed combat chess with resource loops and glory kills.',
    coverUrl: pic('doom-eternal'),
    genres: ['FPS'],
    platforms: ['PC', 'PS5', 'XSX', 'Switch'],
    levels: [
      { number: 1, title: 'Hell on Earth', summary: 'Weapon wheel flow and chainsaw economy.' },
      { number: 2, title: 'Cultist Base', summary: 'Weak points and dash mastery.' },
      { number: 3, title: 'ARC Complex', summary: 'Arena reading and resource triad.' },
    ],
  },
  {
    title: 'Fortnite',
    slug: 'fortnite',
    description:
      'BR with rapid building, rotations, and aim fundamentals.',
    coverUrl: pic('fortnite'),
    genres: ['Battle Royale'],
    platforms: ['PC', 'Consoles', 'Mobile'],
    levels: [
      { number: 1, title: 'Landing & Loot', summary: 'POI choice and early mats.' },
      { number: 2, title: 'Midgame Rotations', summary: 'Zone reads and third-party risks.' },
      { number: 3, title: 'Endgame', summary: 'Box fighting and height control.' },
    ],
  },
  {
    title: 'Apex Legends',
    slug: 'apex-legends',
    description:
      'Hero shooter with movement tech and legend synergies.',
    coverUrl: pic('apex-legends'),
    genres: ['Battle Royale', 'Hero Shooter'],
    platforms: ['PC', 'Consoles'],
    levels: [
      { number: 1, title: 'Drop Paths', summary: 'Hot zones vs edge play.' },
      { number: 2, title: 'Team Fights', summary: 'Ability combos and armor swaps.' },
      { number: 3, title: 'Final Rings', summary: 'Positioning and economy.' },
    ],
  },
  {
    title: 'Baldur’s Gate 3',
    slug: 'baldurs-gate-3',
    description:
      'CRPG with choice-driven story and tactical D&D combat.',
    coverUrl: pic('bg3'),
    genres: ['CRPG'],
    platforms: ['PC', 'PS5', 'XSX'],
    levels: [
      { number: 1, title: 'Act 1 Start', summary: 'Party comp and early loot.' },
      { number: 2, title: 'Grymforge', summary: 'Environmental kills and control spells.' },
      { number: 3, title: 'Act 2 Boss', summary: 'Blessings, light, and burst windows.' },
    ],
  },
  {
    title: 'Sekiro: Shadows Die Twice',
    slug: 'sekiro',
    description:
      'Posture duels, parry timing, and enemy knowledge.',
    coverUrl: pic('sekiro'),
    genres: ['Action', 'Soulslike'],
    platforms: ['PC', 'PS4', 'Xbox'],
    levels: [
      { number: 1, title: 'Ashina Outskirts', summary: 'Mikiri and deflect drills.' },
      { number: 2, title: 'Hirata Estate', summary: 'Firecrackers and stealth routes.' },
      { number: 3, title: 'Genichiro', summary: 'Lightning reversal and patience.' },
    ],
  },
  {
    title: 'Resident Evil 4 (Remake)',
    slug: 'resident-evil-4-remake',
    description:
      'Survival horror with resource management and crowd control.',
    coverUrl: pic('re4-remake'),
    genres: ['Horror', 'Action'],
    platforms: ['PC', 'PS5', 'XSX'],
    levels: [
      { number: 1, title: 'Village Fight', summary: 'Barricades and grenade timing.' },
      { number: 2, title: 'Castle Halls', summary: 'Crossbows and shield breakers.' },
      { number: 3, title: 'Island Labs', summary: 'Regenerator handling and magnum usage.' },
    ],
  },
  {
    title: 'Super Mario Odyssey',
    slug: 'super-mario-odyssey',
    description:
      'Open platforming with captures, moons routing, and advanced movement.',
    coverUrl: pic('mario-odyssey'),
    genres: ['Platformer'],
    platforms: ['Switch'],
    levels: [
      { number: 1, title: 'Cap Kingdom', summary: 'Basic cap throws and dives.' },
      { number: 2, title: 'Sand Kingdom', summary: 'Fast moons and skips.' },
      { number: 3, title: 'Metro Kingdom', summary: 'Festival and movement tech.' },
    ],
  },
]



async function upsertGameWithLevels(g) {
  const { slug, levels, ...rest } = g

  let game = await Game.findOneAndUpdate(
    { slug },
    { slug, ...rest },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  )

  // replace existing levels for this game
  await Level.deleteMany({ game: game._id })

  const seederId = await getSeederUserId()

  const docs = levels.map(l => ({
    game: game._id,
    number: l.number,
    title: l.title,
    summary: l.summary || '',
    createdBy: seederId,          // <-- add this
  }))
  await Level.insertMany(docs)

  console.log(`Seeded: ${game.title} (${docs.length} levels)`)
}


async function main() {
  await connect()
  for (const g of GAMES) {
    await upsertGameWithLevels(g)
  }
  console.log('Done.')
  await mongoose.disconnect()
}

main().catch(err => {
  console.error(err)
  process.exit(1)
})
